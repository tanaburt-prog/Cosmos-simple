# TCHD
Teoria del cosmos  hidrodinamico dimencional
